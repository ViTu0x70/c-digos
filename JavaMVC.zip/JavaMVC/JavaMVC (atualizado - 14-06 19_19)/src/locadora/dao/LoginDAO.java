
package locadora.dao;

import locadora.dao.ConnectionMVC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;


public class LoginDAO {
    private Connection conexao;
    
    public boolean LoginCheck (String CPF, String Senha){
             System.out.print("05");
       conexao = (Connection) new ConnectionMVC().getConnection();
       boolean Check = false;
       PreparedStatement comando_sql = null;
       ResultSet resultado = null;
       try{
           comando_sql = conexao.prepareStatement("SELECT * FROM cliente WHERE CPF = ? and senha = ?");
           comando_sql.setString(1,CPF);
           comando_sql.setString(2, Senha);
           comando_sql.execute();
           resultado = comando_sql.executeQuery();
           
           if(resultado.next()){
               Check = true;
            }
           comando_sql.close();
           conexao.close();
           }catch(SQLException u){
               throw new RuntimeException(u);
           } 
               return Check;
           
    
       
    }
    

    
}
