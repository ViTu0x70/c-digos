
package locadora.controller;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import locadora.model.Cliente;
import java.text.ParseException;
import java.util.ArrayList;
import locadora.dao.ExceptionDAO;


public class ClienteController {
    public boolean cadastrarCliente (String nome, String cpf, String email, String idconta,String senha , String dtNascimento) throws ParseException, ExceptionDAO, SQLException{
        // Validação dos parâmetros
        if(nome !=null && nome.length()>0 && validarCPF(cpf) && email != null   
                && email.length()>0 && idconta !=null && idconta.length()>0 && senha.length()>0 && validarData(dtNascimento)){
             // Formatação da data
            SimpleDateFormat formato = new SimpleDateFormat ("dd/MM/yyyy");
            Date data = formato.parse(dtNascimento);
             // Criação de um objeto Cliente com os dados fornecidos
            Cliente cliente = new Cliente (nome,cpf,email,idconta, senha ,data);
            cliente.cadastrarCliente(cliente);
            return true;
          
        }
        return false;
        
    }
    
    public ArrayList<Cliente> listarClientes(String nome) throws ExceptionDAO{
       return new Cliente().listarClientes(nome);
    }
    
    public boolean alterarCliente (int codCliente, String nome, String cpf, String email, String idconta,String senha ,  String dtNascimento) throws ParseException, ExceptionDAO, SQLException{
          // Validação dos parâmetros
        if(nome !=null && nome.length()>0 && validarCPF(cpf) && email != null   
                && email.length()>0 && idconta !=null && idconta.length()>0 && senha.length()>0 && validarData(dtNascimento)){
             // Formatação da data
            SimpleDateFormat formato = new SimpleDateFormat ("dd/MM/yyyy");
            Date data = formato.parse(dtNascimento);
            // Criação de um objeto Cliente com os dados fornecidos
            Cliente cliente = new Cliente (nome,cpf,email,idconta, senha ,data);
             // Definição do código do cliente
            cliente.setCodCliente(codCliente);
             // Chamada ao método alterarCliente do objeto Cliente
            cliente.alterarCliente(cliente);
            return true;
          
        }
        return false;
        
    }
    
    public boolean apagarCliente(int codCliente) throws ExceptionDAO{
        if(codCliente == 0)
            return false;
        else{
           Cliente cliente = new Cliente();
           cliente.setCodCliente(codCliente);
           cliente.apagarCliente(cliente);
           return true;
        }
    }
    
    public boolean validarCPF(String cpf){
        for(int i=0; i< cpf.length();i++){
            if(!Character.isDigit(cpf.charAt(i))){
                if(!(i==3 || i== 7 || i==11)){
                return false;
                }     
            }
        }
        return true;
    }
    
    public boolean validarData(String data){
        for(int i=0; i< data.length();i++){
            if(!Character.isDigit(data.charAt(i))){
                if(!(i==2 || i== 5)){
                    return false;
                } 
            }
        }
        return true;
    }

    public void inserirCliente() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

    
