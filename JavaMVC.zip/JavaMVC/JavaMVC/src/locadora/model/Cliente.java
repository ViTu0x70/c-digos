
package locadora.model;

import java.util.ArrayList;
import java.util.Date;
import locadora.dao.ClienteDAO;
import locadora.dao.ExceptionDAO;


public class Cliente {
    private Integer codCliente;
    private String nome;
    private String cpf;
    private String email;
    private Date dtNascimento;
    private String endereço;
    private String senha;
    
    public Cliente(){}
    
    public Cliente (String nome, String cpf, String email,String endereço, String senha ,  Date dtNascimento){
        this.nome = nome;
        this.cpf = cpf;
        this.endereço = endereço;
        this.dtNascimento = dtNascimento;
        this.email = email;
        this.senha = senha;
    }

    public Integer getCodCliente() {
        return codCliente;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEmail() {
        return email;
    }

    public Date getDtNascimento() {
        return dtNascimento;
    }

    public String getEndereço() {
        return endereço;
    }
    
    public String getSenha(){
        return senha;
    }

    public void setCodCliente(Integer codCliente) {
        this.codCliente = codCliente;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDtNascimento(Date dtNascimento) {
        this.dtNascimento = dtNascimento;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }
    
    public void setSenha(String senha){
        this.senha = senha;
    }
    
    public void cadastrarCliente(Cliente cliente) throws ExceptionDAO{
        new ClienteDAO().cadastrarCliente(cliente);
    }
    public ArrayList<Cliente> listarClientes(String nome) throws ExceptionDAO{
        return new ClienteDAO().listarClientes(nome);
    }
    
     public void alterarCliente(Cliente cliente) throws ExceptionDAO{
        new ClienteDAO().alterarCliente(cliente);
    }
     
      public void apagarCliente(Cliente cliente) throws ExceptionDAO{
        new ClienteDAO().apagarCliente(cliente);
    }
}