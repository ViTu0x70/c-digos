/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locadora.dao;

import java.sql.Connection; // faz as importações de classes necessárias para o funcionamento do programa 
import java.sql.DriverManager; // conexão SQL para Java 
import java.sql.SQLException; // driver de conexão SQL para Java 

public class ConnectionMVC { // classe para tratamento de exceções 
    public Connection getConnection() {
		try {                                //"jdbc:mysql://localhost/nome_banco","root","senha_root"
                    return DriverManager.getConnection("jdbc:mysql://localhost/mvc","root","qwerty");
		 } 
		 catch(SQLException excecao) {
			throw new RuntimeException(excecao);
		 }
    }
}
