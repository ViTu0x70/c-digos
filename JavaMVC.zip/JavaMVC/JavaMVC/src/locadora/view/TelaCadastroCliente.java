/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package locadora.view;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import locadora.controller.ClienteController;
import locadora.dao.ExceptionDAO;

public class TelaCadastroCliente extends javax.swing.JFrame {
    
     public static boolean isCPF(String CPF) {
        // remove caracteres não numéricos
        CPF = CPF.replaceAll("[^0-9]", "");

        // verifica se a string tem 11 dígitos
        if (CPF.length() != 11)
            return false;

        // verifica se todos os dígitos são iguais
        if (CPF.matches("(\\d)\\1*"))
            return false;

        // Calcula o dígito verificador do CPF
        int digito1 = calcularDigitoVerificador(CPF.substring(0, 9), 10);
        int digito2 = calcularDigitoVerificador(CPF.substring(0, 9) + digito1, 11);

        // Verifica se os dígitos verificadores calculados são iguais aos fornecidos
        return CPF.equals(CPF.substring(0, 9) + Integer.toString(digito1) + Integer.toString(digito2));
    }

    private static int calcularDigitoVerificador(String CPF, int peso) {
        int soma = 0;
        for (int i = 0; i < CPF.length(); i++) {
            soma += Integer.parseInt(CPF.substring(i, i + 1)) * peso--;
        }
        int resto = soma % 11;
        return resto < 2 ? 0 : 11 - resto;
    }
    
    private TelaPrincipal telaPrincipal;
    private Integer codCliente = 0;
    
    public TelaCadastroCliente() {
        initComponents();
    }

    private void limparTela(){
        TextField_Nome.setText("");
        FormattedTextField_DtNascimento.setText("");
        FormattedTextField_CPF.setText("");
        TextField_Email.setText("");
        TextField_Endereco.setText("");
        Camp_Senha.setText("");
    }
    
    
     public void buscarCliente(Integer codCliente, String nome, String cpf, String email, String endereço, Date dtNascimento, String senha) {
        this.codCliente = codCliente;
        this.TextField_Nome.setText(nome);
        this.FormattedTextField_CPF.setText(cpf);
        this.TextField_Email.setText(email);
        this.TextField_Endereco.setText(endereço);
        SimpleDateFormat mask = new SimpleDateFormat("dd/MM/yyyy");
        this.FormattedTextField_DtNascimento.setText(mask.format(dtNascimento));
        this.Camp_Senha.setText(senha);
    }
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        Panel_CadastroCliente = new javax.swing.JPanel();
        Label_Nome = new javax.swing.JLabel();
        TextField_Nome = new javax.swing.JTextField();
        Label_DtNascimento = new javax.swing.JLabel();
        FormattedTextField_DtNascimento = new javax.swing.JFormattedTextField();
        Label_CPF = new javax.swing.JLabel();
        FormattedTextField_CPF = new javax.swing.JFormattedTextField();
        Label_Email = new javax.swing.JLabel();
        TextField_Email = new javax.swing.JTextField();
        Label_Endereco = new javax.swing.JLabel();
        TextField_Endereco = new javax.swing.JTextField();
        Button_Inserir = new javax.swing.JButton();
        Button_Limpar = new javax.swing.JButton();
        Button_Buscar = new javax.swing.JButton();
        Button_Apagar = new javax.swing.JButton();
        Label_Senha1 = new javax.swing.JLabel();
        Camp_Senha = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("UNP BANK");
        setResizable(false);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Sem título_1.png"))); // NOI18N
        jLabel1.setText("Cadastro de Clientes");

        Panel_CadastroCliente.setBackground(new java.awt.Color(102, 102, 102));
        Panel_CadastroCliente.setPreferredSize(new java.awt.Dimension(780, 400));

        Label_Nome.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Label_Nome.setForeground(new java.awt.Color(255, 255, 255));
        Label_Nome.setText("Nome:");

        TextField_Nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextField_NomeActionPerformed(evt);
            }
        });

        Label_DtNascimento.setBackground(new java.awt.Color(255, 255, 255));
        Label_DtNascimento.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Label_DtNascimento.setForeground(new java.awt.Color(255, 255, 255));
        Label_DtNascimento.setText("Data de Nascimento:");

        try {
            FormattedTextField_DtNascimento.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        FormattedTextField_DtNascimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FormattedTextField_DtNascimentoActionPerformed(evt);
            }
        });

        Label_CPF.setBackground(new java.awt.Color(255, 255, 255));
        Label_CPF.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Label_CPF.setForeground(new java.awt.Color(255, 255, 255));
        Label_CPF.setText("CPF:");

        try {
            FormattedTextField_CPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        FormattedTextField_CPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FormattedTextField_CPFActionPerformed(evt);
            }
        });

        Label_Email.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Label_Email.setForeground(new java.awt.Color(255, 255, 255));
        Label_Email.setText("E-mail:");

        TextField_Email.setToolTipText("Informe o E-mail do Cliente");
        TextField_Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextField_EmailActionPerformed(evt);
            }
        });

        Label_Endereco.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Label_Endereco.setForeground(new java.awt.Color(255, 255, 255));
        Label_Endereco.setText("Endereço:");

        TextField_Endereco.setToolTipText("Informe o Endereço do Cliente ");
        TextField_Endereco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextField_EnderecoActionPerformed(evt);
            }
        });

        Button_Inserir.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Button_Inserir.setText("Inserir");
        Button_Inserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_InserirActionPerformed(evt);
            }
        });

        Button_Limpar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Button_Limpar.setText("Limpar");
        Button_Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_LimparActionPerformed(evt);
            }
        });

        Button_Buscar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Button_Buscar.setText("Buscar");
        Button_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrir_TelaConsultaCliente(evt);
            }
        });

        Button_Apagar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Button_Apagar.setText("Apagar");
        Button_Apagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_ApagarActionPerformed(evt);
            }
        });

        Label_Senha1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Label_Senha1.setForeground(new java.awt.Color(255, 255, 255));
        Label_Senha1.setText("Senha:");

        Camp_Senha.setToolTipText("Informe o E-mail do Cliente");
        Camp_Senha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Camp_SenhaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel_CadastroClienteLayout = new javax.swing.GroupLayout(Panel_CadastroCliente);
        Panel_CadastroCliente.setLayout(Panel_CadastroClienteLayout);
        Panel_CadastroClienteLayout.setHorizontalGroup(
            Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_CadastroClienteLayout.createSequentialGroup()
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Label_Nome, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(Panel_CadastroClienteLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(Label_Endereco)
                                .addComponent(Label_Email)
                                .addComponent(Label_CPF)
                                .addComponent(Label_DtNascimento))
                            .addComponent(Label_Senha1, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(TextField_Email, javax.swing.GroupLayout.DEFAULT_SIZE, 456, Short.MAX_VALUE)
                        .addComponent(TextField_Nome)
                        .addComponent(TextField_Endereco)
                        .addComponent(Camp_Senha, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(FormattedTextField_CPF, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(FormattedTextField_DtNascimento, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                    .addGroup(Panel_CadastroClienteLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(Button_Inserir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Button_Limpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Button_Buscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Button_Apagar)))
                .addContainerGap(157, Short.MAX_VALUE))
        );
        Panel_CadastroClienteLayout.setVerticalGroup(
            Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_CadastroClienteLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_Nome)
                    .addComponent(TextField_Nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_DtNascimento)
                    .addComponent(FormattedTextField_DtNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_CPF)
                    .addComponent(FormattedTextField_CPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_Email)
                    .addComponent(TextField_Email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_Endereco)
                    .addComponent(TextField_Endereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_Senha1)
                    .addComponent(Camp_Senha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Panel_CadastroClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Button_Limpar)
                    .addComponent(Button_Buscar)
                    .addComponent(Button_Apagar)
                    .addComponent(Button_Inserir))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Panel_CadastroCliente, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 802, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Panel_CadastroCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 352, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Button_InserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_InserirActionPerformed
         boolean sucesso;
    try {
        String cpf = FormattedTextField_CPF.getText();

        // Verifica se o CPF é válido
        if (!TelaCadastroCliente.isCPF(cpf)) {
            JOptionPane.showMessageDialog(null, "O CPF digitado é inválido. Por favor, reescreva seu CPF.");
            return;
        }

        ClienteController clienteController = new ClienteController();
        
        // Extrai a data de nascimento
    String dtNascimento = FormattedTextField_DtNascimento.getText();
    int anoNascimento = Integer.parseInt(dtNascimento.substring(6, 10));
    int mesNascimento = Integer.parseInt(dtNascimento.substring(3, 5));
    int diaNascimento = Integer.parseInt(dtNascimento.substring(0, 2));

    // Calcula a idade
    LocalDate hoje = LocalDate.now();
    LocalDate dataNascimento = LocalDate.of(anoNascimento, mesNascimento, diaNascimento);
    int idade = Period.between(dataNascimento, hoje).getYears();

    // Verifica se a idade está dentro do intervalo aceitável
    if (idade < 18 || idade > 120) {
        JOptionPane.showMessageDialog(null, "Idade inválida. A idade deve estar entre 18 e 120 anos.");
        return;
    }

        if (this.codCliente == 0) {
            sucesso = clienteController.cadastrarCliente(TextField_Nome.getText(), cpf,
                    TextField_Email.getText(), TextField_Endereco.getText(),Camp_Senha.getText(),
                    FormattedTextField_DtNascimento.getText());
        } else {
            sucesso = clienteController.alterarCliente(this.codCliente, TextField_Nome.getText(), cpf,
                    TextField_Email.getText(), TextField_Endereco.getText(),Camp_Senha.getText(),
                    FormattedTextField_DtNascimento.getText());
        }

        if (sucesso) {
            JOptionPane.showMessageDialog(null, " O Cadastro foi realizado com sucesso");
            this.Button_LimparActionPerformed(evt);
        } else {
            JOptionPane.showMessageDialog(null, " Os campos não foram preenchidos corretamente");

        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "erro" + e);
    }
        
    }//GEN-LAST:event_Button_InserirActionPerformed

    private void TextField_EnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextField_EnderecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextField_EnderecoActionPerformed

    private void TextField_EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextField_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextField_EmailActionPerformed

    private void FormattedTextField_CPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FormattedTextField_CPFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FormattedTextField_CPFActionPerformed

    private void FormattedTextField_DtNascimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FormattedTextField_DtNascimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FormattedTextField_DtNascimentoActionPerformed

    private void TextField_NomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextField_NomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextField_NomeActionPerformed

    private void abrir_TelaConsultaCliente(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrir_TelaConsultaCliente
        TelaConsultaCliente telaConsultaCliente = new TelaConsultaCliente(this);
        this.setVisible(false);
        telaConsultaCliente.setVisible(true);
        
    }//GEN-LAST:event_abrir_TelaConsultaCliente

    private void Button_ApagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_ApagarActionPerformed
        boolean sucesso;
        ClienteController clienteController = new ClienteController();
        try {
            sucesso = clienteController.apagarCliente(this.codCliente);
            if (sucesso){
                JOptionPane.showMessageDialog(null, "O cliente foi apagado com sucesso");
                this.limparTela();
            }else
                JOptionPane.showMessageDialog(null, "O cliente não foi apagado. Por favor, selecione um cliente");

        } catch (ExceptionDAO ex) {
            Logger.getLogger(TelaCadastroCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }//GEN-LAST:event_Button_ApagarActionPerformed

    private void Button_LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_LimparActionPerformed
        this.limparTela();
    }//GEN-LAST:event_Button_LimparActionPerformed

    private void Camp_SenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Camp_SenhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Camp_SenhaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastroCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Button_Apagar;
    private javax.swing.JButton Button_Buscar;
    private javax.swing.JButton Button_Inserir;
    private javax.swing.JButton Button_Limpar;
    private javax.swing.JTextField Camp_Senha;
    private javax.swing.JFormattedTextField FormattedTextField_CPF;
    private javax.swing.JFormattedTextField FormattedTextField_DtNascimento;
    private javax.swing.JLabel Label_CPF;
    private javax.swing.JLabel Label_DtNascimento;
    private javax.swing.JLabel Label_Email;
    private javax.swing.JLabel Label_Endereco;
    private javax.swing.JLabel Label_Nome;
    private javax.swing.JLabel Label_Senha1;
    private javax.swing.JPanel Panel_CadastroCliente;
    private javax.swing.JTextField TextField_Email;
    private javax.swing.JTextField TextField_Endereco;
    private javax.swing.JTextField TextField_Nome;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables

   

}