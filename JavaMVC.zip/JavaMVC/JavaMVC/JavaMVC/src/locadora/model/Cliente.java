
package locadora.model;


import java.util.Date;


public class Cliente {
    private Integer codCliente;
    private String nome;
    private String cpf;
    private String email;
    private Date dtNascimento;
    
    public Cliente (String nome, String cpf, String email,String endereço, Date dtNascimento){
        this.nome = nome;
        this.cpf = cpf;
        this.email = endereço;
        this.dtNascimento = dtNascimento;
    }

    public Integer getCodCliente() {
        return codCliente;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEmail() {
        return email;
    }

    public Date getDtNascimento() {
        return dtNascimento;
    }

    public void setCodCliente(Integer codCliente) {
        this.codCliente = codCliente;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDtNascimento(Date dtNascimento) {
        this.dtNascimento = dtNascimento;
    }
    public void cadastrarCliente (Cliente cliente){
        
    }
    
    
    
}
